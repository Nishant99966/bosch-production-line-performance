from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from .config import ensure_output_dirs, load_config
from .io import load_frame
from .model import fit_full, train_with_validation


def run(config_path: str) -> None:
    cfg = load_config(config_path)
    ensure_output_dirs(cfg)
    processed = Path(cfg["paths"]["processed_dir"])
    artifacts = Path(cfg["paths"]["artifacts_dir"])

    train_path = processed / "train_features.parquet"
    test_path = processed / "test_features.parquet"
    train = load_frame(train_path)
    test = load_frame(test_path)
    y = train.pop("Response").astype("int8")
    train_ids = train.pop("Id")
    test_ids = test.pop("Id")

    # Keep feature schemas aligned.
    missing_in_test = [c for c in train.columns if c not in test.columns]
    if missing_in_test:
        raise ValueError(f"Test feature schema is missing columns: {missing_in_test[:10]}")
    test = test[train.columns]

    print(f"Training rows: {len(train):,}; features: {train.shape[1]:,}; positive rate: {y.mean():.5f}")
    validation_model, metrics = train_with_validation(
        train, y, cfg["validation"], cfg["model"]
    )
    print(json.dumps(metrics, indent=2))

    final_model = fit_full(train, y, cfg["model"], metrics["best_iteration"])
    final_model.booster_.save_model(str(artifacts / "model.txt"))

    importance = pd.DataFrame(
        {
            "feature": train.columns,
            "importance_gain": final_model.booster_.feature_importance(importance_type="gain"),
            "importance_split": final_model.booster_.feature_importance(importance_type="split"),
        }
    ).sort_values("importance_gain", ascending=False)
    importance.to_csv(artifacts / "feature_importance.csv", index=False)

    test_prob = final_model.predict_proba(test)[:, 1]
    threshold = float(metrics["optimal_threshold"])
    submission = pd.DataFrame(
        {"Id": test_ids.to_numpy(), "Response": (test_prob >= threshold).astype("int8")}
    )
    submission.to_csv(artifacts / "submission.csv", index=False)

    metrics["test_predicted_positive_rate"] = float(submission["Response"].mean())
    metrics["feature_count"] = int(train.shape[1])
    (artifacts / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(f"Saved model, metrics, importances and submission to {artifacts}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs.yaml")
    args = parser.parse_args()
    run(args.config)


if __name__ == "__main__":
    main()
