from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from .config import ensure_output_dirs, load_config
from .features import (
    add_temporal_order_features,
    build_categorical_features,
    build_date_features,
    build_numeric_features,
    select_categorical_columns,
)
from .io import save_frame, validate_raw_data
from .numeric_selection import score_numeric_features


def run(config_path: str) -> None:
    cfg = load_config(config_path)
    ensure_output_dirs(cfg)
    raw = Path(cfg["paths"]["raw_dir"])
    processed = Path(cfg["paths"]["processed_dir"])
    chunk_size = int(cfg["io"]["chunk_size"])
    feat_cfg = cfg["features"]
    include_cat = bool(feat_cfg.get("include_categorical", True))

    validate_raw_data(raw, include_categorical=include_cat)

    print("[1/6] Scoring numeric features...")
    numeric_scores = score_numeric_features(
        raw / "train_numeric.csv",
        chunk_size=chunk_size,
        min_coverage=float(feat_cfg.get("min_numeric_coverage", 0.0)),
    )
    selected_numeric = numeric_scores.head(int(feat_cfg["numeric_top_k"]))["feature"].tolist()
    numeric_scores.to_csv(processed / "numeric_feature_scores.csv", index=False)

    print("[2/6] Building numeric feature blocks...")
    train_num = build_numeric_features(
        raw / "train_numeric.csv", selected_numeric, chunk_size, is_train=True
    )
    test_num = build_numeric_features(
        raw / "test_numeric.csv", selected_numeric, chunk_size, is_train=False
    )

    print("[3/6] Compressing date features by station...")
    train_date = build_date_features(raw / "train_date.csv", chunk_size)
    test_date = build_date_features(raw / "test_date.csv", chunk_size)
    train_date, test_date = add_temporal_order_features(train_date, test_date)

    print("[4/6] Processing compact categorical features...")
    selected_cat: list[str] = []
    if include_cat:
        selected_cat = select_categorical_columns(
            raw / "train_categorical.csv",
            top_k=int(feat_cfg["categorical_top_k"]),
            min_coverage=float(feat_cfg.get("min_categorical_coverage", 0.0)),
            chunk_size=chunk_size,
        )
        train_cat, test_cat = build_categorical_features(
            raw / "train_categorical.csv",
            raw / "test_categorical.csv",
            selected_cat,
            chunk_size,
        )
    else:
        train_cat = train_num[["Id"]].copy()
        test_cat = test_num[["Id"]].copy()

    print("[5/6] Joining feature blocks...")
    train = train_num.merge(train_date, on="Id", how="left", validate="one_to_one")
    train = train.merge(train_cat, on="Id", how="left", validate="one_to_one")
    test = test_num.merge(test_date, on="Id", how="left", validate="one_to_one")
    test = test.merge(test_cat, on="Id", how="left", validate="one_to_one")

    train = train.sort_values("Id").reset_index(drop=True)
    test = test.sort_values("Id").reset_index(drop=True)

    print("[6/6] Writing Parquet datasets...")
    train_saved = save_frame(train, processed / "train_features.parquet")
    test_saved = save_frame(test, processed / "test_features.parquet")

    metadata = {
        "train_rows": len(train),
        "test_rows": len(test),
        "feature_count": len([c for c in train.columns if c not in {"Id", "Response"}]),
        "train_feature_file": str(train_saved),
        "test_feature_file": str(test_saved),
        "selected_numeric": selected_numeric,
        "selected_categorical": selected_cat,
    }
    (processed / "feature_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata | {"selected_numeric": len(selected_numeric), "selected_categorical": len(selected_cat)}, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs.yaml")
    args = parser.parse_args()
    run(args.config)


if __name__ == "__main__":
    main()
