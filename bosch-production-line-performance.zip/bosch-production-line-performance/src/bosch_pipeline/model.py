from __future__ import annotations

import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import train_test_split

from .metrics import optimize_mcc_threshold


def make_split(
    frame: pd.DataFrame,
    y: pd.Series,
    strategy: str,
    validation_fraction: float,
    random_state: int,
) -> tuple[np.ndarray, np.ndarray]:
    n = len(frame)
    indices = np.arange(n)
    if strategy == "chronological" and "start_time" in frame.columns:
        order = np.argsort(frame["start_time"].fillna(np.inf).to_numpy(), kind="stable")
        cut = max(1, int(n * (1.0 - validation_fraction)))
        return order[:cut], order[cut:]
    if strategy == "stratified":
        tr, va = train_test_split(
            indices,
            test_size=validation_fraction,
            random_state=random_state,
            stratify=y,
        )
        return np.asarray(tr), np.asarray(va)
    raise ValueError(f"Unknown validation strategy: {strategy}")


def train_with_validation(
    x: pd.DataFrame,
    y: pd.Series,
    validation_cfg: dict,
    model_cfg: dict,
):
    train_idx, valid_idx = make_split(
        x,
        y,
        strategy=validation_cfg["strategy"],
        validation_fraction=float(validation_cfg["validation_fraction"]),
        random_state=int(validation_cfg["random_state"]),
    )

    y_train = y.iloc[train_idx]
    y_valid = y.iloc[valid_idx]
    pos = max(int(y_train.sum()), 1)
    neg = max(len(y_train) - pos, 1)
    scale_pos_weight = neg / pos

    params = dict(model_cfg)
    early_stopping_rounds = int(params.pop("early_stopping_rounds", 100))
    model = lgb.LGBMClassifier(
        objective="binary",
        scale_pos_weight=scale_pos_weight,
        verbosity=-1,
        **params,
    )
    callbacks = [lgb.early_stopping(early_stopping_rounds, verbose=False)]
    model.fit(
        x.iloc[train_idx],
        y_train,
        eval_set=[(x.iloc[valid_idx], y_valid)],
        eval_metric="binary_logloss",
        callbacks=callbacks,
    )

    prob = model.predict_proba(x.iloc[valid_idx])[:, 1]
    threshold, mcc = optimize_mcc_threshold(y_valid.to_numpy(), prob)
    metrics = {
        "validation_mcc": float(mcc),
        "optimal_threshold": float(threshold),
        "roc_auc": float(roc_auc_score(y_valid, prob)) if y_valid.nunique() > 1 else None,
        "average_precision": float(average_precision_score(y_valid, prob)) if y_valid.nunique() > 1 else None,
        "best_iteration": int(model.best_iteration_ or model_cfg["n_estimators"]),
        "validation_strategy": validation_cfg["strategy"],
        "train_rows": int(len(train_idx)),
        "validation_rows": int(len(valid_idx)),
        "positive_rate_train": float(y_train.mean()),
        "positive_rate_validation": float(y_valid.mean()),
    }
    return model, metrics


def fit_full(x: pd.DataFrame, y: pd.Series, model_cfg: dict, best_iteration: int):
    pos = max(int(y.sum()), 1)
    neg = max(len(y) - pos, 1)
    params = dict(model_cfg)
    params.pop("early_stopping_rounds", None)
    params["n_estimators"] = max(int(best_iteration), 1)
    model = lgb.LGBMClassifier(
        objective="binary",
        scale_pos_weight=neg / pos,
        verbosity=-1,
        **params,
    )
    model.fit(x, y)
    return model
