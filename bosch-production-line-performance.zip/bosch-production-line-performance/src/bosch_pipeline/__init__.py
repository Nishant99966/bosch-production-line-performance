"""Bosch production-line failure prediction pipeline."""

__version__ = "0.1.0"
