from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd

from .io import read_header


STATION_RE = re.compile(r"(L\d+_S\d+)_")
LINE_RE = re.compile(r"(L\d+)_S\d+_")


def _station_from_col(col: str) -> str | None:
    m = STATION_RE.search(col)
    return m.group(1) if m else None


def _line_from_col(col: str) -> str | None:
    m = LINE_RE.search(col)
    return m.group(1) if m else None


def build_date_features(path: str | Path, chunk_size: int) -> pd.DataFrame:
    columns = read_header(path)
    date_cols = [c for c in columns if c != "Id"]
    station_map: dict[str, list[str]] = {}
    for col in date_cols:
        station = _station_from_col(col)
        if station:
            station_map.setdefault(station, []).append(col)

    frames: list[pd.DataFrame] = []
    for chunk in pd.read_csv(path, chunksize=chunk_size, low_memory=False):
        ids = chunk["Id"].to_numpy()
        out: dict[str, np.ndarray] = {"Id": ids}
        station_mins = []
        station_maxs = []
        station_names = []

        for station, cols in station_map.items():
            vals = chunk[cols]
            smin = vals.min(axis=1, skipna=True).to_numpy(dtype=np.float32)
            smax = vals.max(axis=1, skipna=True).to_numpy(dtype=np.float32)
            out[f"date_{station}_min"] = smin
            out[f"date_{station}_max"] = smax
            out[f"date_{station}_span"] = (smax - smin).astype(np.float32)
            station_mins.append(smin)
            station_maxs.append(smax)
            station_names.append(station)

        mins = np.column_stack(station_mins) if station_mins else np.empty((len(chunk), 0))
        maxs = np.column_stack(station_maxs) if station_maxs else np.empty((len(chunk), 0))
        if mins.shape[1]:
            with np.errstate(all="ignore"):
                out["start_time"] = np.nanmin(mins, axis=1).astype(np.float32)
                out["end_time"] = np.nanmax(maxs, axis=1).astype(np.float32)
            out["production_duration"] = (out["end_time"] - out["start_time"]).astype(np.float32)
            visited = np.isfinite(mins)
            out["stations_visited"] = visited.sum(axis=1).astype(np.int16)
            out["date_missing_fraction"] = (1.0 - visited.mean(axis=1)).astype(np.float32)

            lines = sorted({name.split("_")[0] for name in station_names})
            for line in lines:
                idx = [i for i, s in enumerate(station_names) if s.startswith(f"{line}_")]
                out[f"stations_visited_{line}"] = visited[:, idx].sum(axis=1).astype(np.int16)

        frames.append(pd.DataFrame(out))
    return pd.concat(frames, ignore_index=True)


def add_temporal_order_features(train_dates: pd.DataFrame, test_dates: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    tr = train_dates.copy()
    te = test_dates.copy()
    tr["__split"] = 0
    te["__split"] = 1
    both = pd.concat([tr, te], ignore_index=True)

    sort_start = both["start_time"].fillna(np.inf)
    order = np.lexsort((both["Id"].to_numpy(), sort_start.to_numpy()))
    ordered = both.iloc[order].copy()

    ordered["prev_start_gap"] = ordered["start_time"].diff().astype(np.float32)
    ordered["next_start_gap"] = (-ordered["start_time"].diff(-1)).astype(np.float32)
    ordered["prev_id_gap_time_order"] = ordered["Id"].diff().astype(np.float32)
    ordered["next_id_gap_time_order"] = (-ordered["Id"].diff(-1)).astype(np.float32)

    group = ordered.groupby("start_time", dropna=False, sort=False)
    ordered["same_start_count"] = group["Id"].transform("size").astype(np.int32)
    ordered["same_start_rank"] = group.cumcount().astype(np.int32)
    denom = np.maximum(ordered["same_start_count"].to_numpy() - 1, 1)
    ordered["same_start_rank_frac"] = (ordered["same_start_rank"].to_numpy() / denom).astype(np.float32)

    restored = ordered.sort_index()
    train_out = restored[restored["__split"] == 0].drop(columns="__split").reset_index(drop=True)
    test_out = restored[restored["__split"] == 1].drop(columns="__split").reset_index(drop=True)
    return train_out, test_out


def build_numeric_features(
    path: str | Path,
    selected: list[str],
    chunk_size: int,
    is_train: bool,
) -> pd.DataFrame:
    usecols = ["Id", *selected]
    if is_train:
        usecols.append("Response")
    frames: list[pd.DataFrame] = []

    for chunk in pd.read_csv(path, usecols=usecols, chunksize=chunk_size, low_memory=False):
        ids = chunk["Id"].to_numpy()
        out = pd.DataFrame({"Id": ids})
        if is_train:
            out["Response"] = chunk["Response"].astype(np.int8).to_numpy()

        selected_frame = chunk[selected].apply(pd.to_numeric, errors="coerce")
        for col in selected:
            out[f"num_{col}"] = selected_frame[col].astype(np.float32)

        arr = selected_frame.to_numpy(dtype=np.float32, copy=False)
        finite = np.isfinite(arr)
        out["numeric_selected_present"] = finite.sum(axis=1).astype(np.int16)
        out["numeric_selected_missing"] = (~finite).sum(axis=1).astype(np.int16)
        with np.errstate(all="ignore"):
            out["numeric_selected_mean"] = np.nanmean(arr, axis=1).astype(np.float32)
            out["numeric_selected_std"] = np.nanstd(arr, axis=1).astype(np.float32)
            out["numeric_selected_min"] = np.nanmin(arr, axis=1).astype(np.float32)
            out["numeric_selected_max"] = np.nanmax(arr, axis=1).astype(np.float32)
        frames.append(out)

    return pd.concat(frames, ignore_index=True)


def select_categorical_columns(train_path: str | Path, top_k: int, min_coverage: float, chunk_size: int) -> list[str]:
    columns = [c for c in read_header(train_path) if c != "Id"]
    nonnull = np.zeros(len(columns), dtype=np.int64)
    rows = 0
    for chunk in pd.read_csv(train_path, usecols=columns, chunksize=chunk_size, dtype="string", low_memory=False):
        nonnull += chunk.notna().sum(axis=0).to_numpy(dtype=np.int64)
        rows += len(chunk)
    coverage = nonnull / max(rows, 1)
    idx = np.where(coverage >= min_coverage)[0]
    idx = idx[np.argsort(-coverage[idx], kind="stable")]
    return [columns[i] for i in idx[:top_k]]


def build_categorical_features(
    train_path: str | Path,
    test_path: str | Path,
    selected: list[str],
    chunk_size: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    if not selected:
        train_ids = pd.read_csv(train_path, usecols=["Id"])
        test_ids = pd.read_csv(test_path, usecols=["Id"])
        return train_ids, test_ids

    def read_selected(path: str | Path) -> pd.DataFrame:
        frames = []
        for chunk in pd.read_csv(
            path,
            usecols=["Id", *selected],
            chunksize=chunk_size,
            dtype={c: "string" for c in selected},
            low_memory=False,
        ):
            frames.append(chunk)
        return pd.concat(frames, ignore_index=True)

    train = read_selected(train_path)
    test = read_selected(test_path)
    n_train = len(train)
    combined = pd.concat([train, test], ignore_index=True)
    out = pd.DataFrame({"Id": combined["Id"].to_numpy()})

    for col in selected:
        vals = combined[col].fillna("__MISSING__")
        codes, uniques = pd.factorize(vals, sort=False)
        out[f"cat_{col}"] = codes.astype(np.int32)
        counts = pd.Series(codes).value_counts(dropna=False)
        out[f"catfreq_{col}"] = pd.Series(codes).map(counts).to_numpy(dtype=np.int32)

    return out.iloc[:n_train].reset_index(drop=True), out.iloc[n_train:].reset_index(drop=True)
