# Project Report — Bosch Production Line Performance

## 1. Problem statement

The objective is to predict whether a manufactured part will fail Bosch's internal quality control. Each row represents a part and contains anonymized measurements captured at multiple production lines and stations. Features are split into numeric, categorical and timestamp files.

The target is extremely imbalanced, making plain accuracy inappropriate. The competition uses Matthews Correlation Coefficient (MCC), which incorporates all four confusion-matrix cells and remains informative when one class is rare.

## 2. Data challenges

1. More than one million rows.
2. Thousands of columns.
3. Heavy sparsity because a part only visits a subset of stations.
4. Mixed feature types stored in separate files.
5. Strong class imbalance.
6. Temporal/process dependencies between parts.
7. Memory limits on ordinary workstations.

## 3. Architecture

The project uses a two-stage architecture:

### Stage A — Feature preparation

- Read raw CSVs in chunks.
- Compress date columns by station.
- Derive process timing and routing features.
- Score numeric columns with streaming class statistics and retain a compact subset.
- Add numeric row summaries.
- Add compact categorical encodings for the best-covered categorical columns.
- Join all engineered blocks by `Id`.
- Save train/test features as Parquet.

### Stage B — Modeling

- Load processed features.
- Split train/validation chronologically by default.
- Train LightGBM with class weighting.
- Tune the probability threshold for validation MCC.
- Refit on full training data using the best iteration count.
- Predict test probabilities, threshold them, and save the Kaggle submission.

## 4. Feature engineering

### 4.1 Station timestamps

Feature names encode line and station, for example `L3_S36_D3919`. Date columns belonging to the same station are aggregated into station-level minimum and maximum timestamps.

Derived features include global start, global end, total duration, number of stations visited, line coverage, per-station range and overall missingness.

### 4.2 Temporal ordering

Train and test rows are concatenated only for label-free ordering features. Rows are sorted by global start time and `Id`. The pipeline derives previous/next start-time gaps, adjacent ID gaps, equal-start group size and group rank.

### 4.3 Numeric selection

For each numeric feature the preparation stage computes streaming statistics separately for positive and negative classes. The selection score combines:

- absolute class missing-rate difference,
- standardized class mean difference,
- non-missing coverage.

This retains useful raw signal without materializing every numeric feature in the final table.

### 4.4 Categorical features

High-dimensional one-hot encoding can become prohibitively large. The default implementation selects well-covered categorical columns and factorizes train+test values consistently into compact integer codes. Missing values become a dedicated category.

## 5. Model choice

LightGBM is a strong fit for this problem because it handles nonlinear interactions, missing values, sparse signals, large row counts and imbalanced binary classification efficiently.

The model optimizes binary log loss internally, while model selection uses the competition metric MCC.

## 6. Validation strategy

A chronological holdout is the default because manufacturing observations are time-ordered and neighboring parts can be correlated. A random stratified split may produce a more Kaggle-like score, but a temporal split is more conservative and closer to real deployment.

Both can be configured.

## 7. Threshold optimization

The model outputs probabilities. The pipeline evaluates candidate thresholds built from validation prediction quantiles and chooses the threshold with the highest MCC.

This is essential for highly imbalanced data.

## 8. Reproducibility

- Configuration is centralized in YAML.
- Random seeds are fixed.
- Raw data is excluded from source control.
- Unit tests cover MCC thresholding and an end-to-end synthetic pipeline.
- GitHub Actions runs tests on pushes and pull requests.

## 9. Limitations

The repository intentionally avoids label-based neighboring-part features because they are difficult to validate without leakage. Historical competition winners exploited strong dataset-specific ordering properties; reproducing those features can improve leaderboard performance but can reduce real-world generalization.

The repository therefore prioritizes a clean, explainable, reproducible baseline that can be extended with competition-specific features.

## 10. Recommended next experiments

1. Add out-of-fold rolling target statistics by station/time.
2. Add per-station row hashes and duplicate-pattern features.
3. Tune LightGBM with Optuna on MCC.
4. Blend LightGBM and XGBoost probabilities.
5. Compare random-stratified and time-aware cross-validation.
6. Add SHAP analysis aggregated from features to manufacturing stations.
