# Bosch Production Line Performance — End-to-End ML Pipeline

Predict manufacturing quality-control failures from the Bosch Production Line Performance Kaggle dataset.

This repository is designed as a reproducible, memory-aware solution for one of Kaggle's largest tabular datasets: about 1.18 million training parts with thousands of sparse numeric, categorical, and timestamp features. The official metric is Matthews Correlation Coefficient (MCC), so the pipeline explicitly tunes the probability threshold for MCC rather than using the default 0.5 cutoff.

## What this project does

- Downloads the competition data with the Kaggle CLI (after you configure Kaggle credentials).
- Compresses thousands of date columns into station-level timing features.
- Builds production-flow features such as start/end time, duration, station count, temporal gaps, simultaneous-part counts, and line coverage.
- Scans numeric features in chunks and selects informative columns using class-conditional missingness and mean-shift statistics.
- Adds row-level numeric sparsity/summary features.
- Optionally adds compact categorical features without one-hot exploding the dataset.
- Trains a LightGBM classifier with class-imbalance handling.
- Uses a time-aware validation split by default.
- Finds the MCC-optimal decision threshold on validation predictions.
- Produces `submission.csv` in Kaggle format.
- Includes unit tests and a GitHub Actions workflow.

## Competition

Kaggle: Bosch Production Line Performance

https://www.kaggle.com/competitions/bosch-production-line-performance

The target is `Response` (`1` = failed quality control, `0` = passed). The official evaluation metric is Matthews Correlation Coefficient (MCC).

## Repository layout

```text
.
├── README.md
├── PROJECT_REPORT.md
├── requirements.txt
├── pyproject.toml
├── Makefile
├── .gitignore
├── configs.yaml
├── scripts/
│   ├── download_data.sh
│   ├── make_synthetic_data.py
│   └── run_pipeline.sh
├── src/bosch_pipeline/
│   ├── __init__.py
│   ├── config.py
│   ├── io.py
│   ├── metrics.py
│   ├── numeric_selection.py
│   ├── features.py
│   ├── model.py
│   ├── prepare.py
│   └── train.py
├── tests/
│   ├── test_metrics.py
│   └── test_pipeline_smoke.py
└── .github/workflows/tests.yml
```

## 1. Environment setup

Python 3.10–3.12 is recommended for broad package compatibility.

```bash
python -m venv .venv
source .venv/bin/activate      # Linux/macOS
# .venv\Scripts\activate       # Windows PowerShell

pip install -r requirements.txt
pip install -e .
```

## 2. Download Kaggle data

Accept the competition rules on Kaggle first, then configure your Kaggle API credentials.

```bash
bash scripts/download_data.sh
```

Expected files under `data/raw/`:

```text
train_numeric.csv
train_categorical.csv
train_date.csv
test_numeric.csv
test_categorical.csv
test_date.csv
sample_submission.csv
```

The dataset is large. Keep the raw files out of Git; `.gitignore` already excludes them.

## 3. Prepare features

```bash
python -m bosch_pipeline.prepare --config configs.yaml
```

Outputs are written to `data/processed/`:

- `train_features.parquet`
- `test_features.parquet`
- `feature_metadata.json`

The preprocessing step reads CSVs in chunks to limit memory pressure.

## 4. Train and create a submission

```bash
python -m bosch_pipeline.train --config configs.yaml
```

Outputs are written to `artifacts/`:

- `model.txt`
- `metrics.json`
- `feature_importance.csv`
- `submission.csv`

## 5. One-command run

```bash
bash scripts/run_pipeline.sh
```

## 6. Smoke test without Kaggle data

A small Bosch-shaped synthetic dataset is included as a test path:

```bash
python scripts/make_synthetic_data.py --output-dir data/raw_synthetic --rows 3000
python -m bosch_pipeline.prepare --config configs.synthetic.yaml
python -m bosch_pipeline.train --config configs.synthetic.yaml
```

Or simply run:

```bash
pytest -q
```

## Modeling strategy

### Date compression

The raw date file contains many timestamps corresponding to features measured at the same station. Instead of feeding all date columns to the model, the pipeline aggregates per station:

- station minimum timestamp
- station maximum timestamp
- station dwell/range time
- overall start time
- overall end time
- total production duration
- number of visited stations
- first/last station timing patterns

This drastically reduces dimensionality while preserving process-flow information.

### Production-order / temporal features

Historical high-ranking solutions showed that order and timing carried strong signal. This implementation adds non-target-leaking features such as:

- gap to previous/next part in start-time order
- number of parts sharing the same start time
- rank within equal-start-time groups
- ID gap to adjacent temporally ordered parts
- line-level station coverage counts

The feature generation combines train and test only for unsupervised ordering statistics. It never uses test labels (which do not exist) and does not inject neighboring training labels into test rows.

### Numeric feature selection

Loading all numeric columns into a dense frame is expensive. The pipeline performs a streaming scan of training data and scores each numeric feature from:

- difference in missing rates between failed and non-failed parts
- standardized difference in class means
- feature coverage

It then keeps the highest-scoring columns plus row-level summary statistics.

### Imbalance and MCC

Failures are rare. The model uses class weighting and predicts probabilities. A validation-set sweep selects the probability threshold that maximizes MCC.

This is important because the threshold that maximizes MCC is generally not 0.5.

## Validation

`configs.yaml` defaults to a chronological split based on the engineered global start time. This is stricter than a random split and reduces the risk of overstating performance from temporal proximity.

For competition-style experimentation you can set:

```yaml
validation:
  strategy: stratified
```

and compare both approaches.

## Configuration

Key options are in `configs.yaml`:

```yaml
features:
  numeric_top_k: 220
  include_categorical: true
  categorical_top_k: 80

model:
  n_estimators: 1600
  learning_rate: 0.025
  num_leaves: 31
  max_depth: -1
  subsample: 0.85
  colsample_bytree: 0.75
```

Increase/decrease feature counts depending on available RAM.

## Expected hardware

A full run is practical on a machine with approximately 16–32 GB RAM. More memory helps. The preprocessing is chunked, but LightGBM still needs the engineered dataset in memory during fitting.

If you are memory-constrained, reduce:

- `features.numeric_top_k`
- `features.categorical_top_k`
- `io.chunk_size`

## Reproducibility and data licensing

The raw Kaggle competition data is intentionally not committed to this repository. Download it from Kaggle after accepting the competition rules. Generated models, processed data, and submissions are also ignored by Git.

## Results

This repository does **not** claim a Kaggle leaderboard score unless the full Kaggle dataset is actually run. The included automated tests use synthetic data only and verify that the pipeline works end-to-end.

Once you run the full dataset, `artifacts/metrics.json` records validation MCC, optimal threshold, ROC-AUC and average precision.

## Potential extensions

- Out-of-fold target-safe rolling failure-rate features.
- Per-station duplicate-row / hash features inspired by historical top solutions.
- Model stacking across LightGBM/XGBoost/random forest.
- Optuna hyperparameter search.
- SHAP station-level interpretability.
- MLflow or Weights & Biases experiment tracking.

## License

Code in this repository is released under the MIT License. Kaggle competition data remains subject to the competition's own rules and license.
